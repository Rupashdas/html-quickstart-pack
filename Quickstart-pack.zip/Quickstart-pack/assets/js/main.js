;(function($){

    $(document).ready(function(){

    });

    $(document).on('load', function(){

    });
    
})(jQuery);